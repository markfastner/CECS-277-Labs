
public interface State 
{
	public void execute(Robot robot);
}
