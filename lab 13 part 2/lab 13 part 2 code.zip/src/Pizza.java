public class Pizza implements PizzaInt
{
    public void makePizza()
    {
        System.out.println("Make a pizza!");
    }
}