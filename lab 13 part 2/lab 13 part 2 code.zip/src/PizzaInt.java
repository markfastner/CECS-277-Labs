public interface PizzaInt
{
    public void makePizza();
}