import java.util.Comparator;

public class SalaryComparator implements Comparator<Employee> {

    // This compares employees based on salaries
    public int compare(Employee o1, Employee o2) {
        if (o1.salary >= o2.salary) {
            return 1;
        } else {
            return -1;
        }
    }



}
